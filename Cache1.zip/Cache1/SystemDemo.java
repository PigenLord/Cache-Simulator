import java.lang.*;
import java.util.*;

public class SystemDemo {

   public static void main(String[] args) {
   
      double round;

      // returns the current value of the system timer, in nanoseconds
      System.out.print("time in nanoseconds = ");
      System.out.println(System.nanoTime());
      round = Math.ceil(System.nanoTime());
      String strNano = String.valueOf(round);
      
      //System.out.format("Nano segundos redondeados: %.4f%n", round);
      String cadena = "123456789";
      int cantidad = 4;
      int m = Math.max(0, cadena.length() - cantidad);      
      
      System.out.println(cadena.substring(0,cadena.length() - cantidad));
      System.out.println(cadena.subSequence(0,m).toString());
      
      StringBuilder sb = new StringBuilder(cadena);
      sb.setLength(m);
      System.out.println(sb.toString());
      
      char[] cs = cadena.toCharArray();
      System.out.println(new String(cs, 0, m));
      
      System.out.println(String.replaceFirst("[\\s\\S]{0,2}$", ""));
   }
} 