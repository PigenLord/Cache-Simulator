import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.*; 
import java.util.*;
import java.lang.*; 

public class UserCache 
{
   final static String outputFilePath = "E:/HashMapPrueba/CacheMemory.txt";

   String fileName = "MainMemory";
   public static void main(String[] args) throws IOException 
   {
      LRUCache<Integer> cache = new LRUCache<>(4);//HashMap for Cache
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      Scanner input = new Scanner(System.in);
        
      int choice = 1,
          tiempoCache,//Timer
          tiempoMain,//Timer
          tiempoTranscurrido,
          required;
     
      String strRequired,//Pagina que pide el usuario
             strKey,//Guarda el key del hashgmap
             strFound,//Hit o Miss Mensaje
             strStatus,//Mensaje del Status
             strPagina,//Va a tener el valor del Key para saber la Pagina
             subKey;//Se usa para identificar la llave que se cambiara el valor
      boolean found = false;//Determina si hay un miss o un hit
      
      while(choice != 0)
      { 
         System.out.println("1: Put\n2: Get\n0: Exit");
         choice = Integer.parseInt(br.readLine());   
         switch (choice)
         {
         
            case 1://Create the key and value
               
               for(int x = 0; x < 4; x++)
               {
                  System.out.println("Tiempo acceso cache: " + System.nanoTime());
                  System.out.println("Tiempo acceso main: " + System.nanoTime());
                  System.out.println("Algoritmo reemplazo: LRU");
                 
                  System.out.print("Se requiere: ");//Pregunta al usuario que quiere buscar en el cache
                  strRequired = input.nextLine();
                  required = Integer.parseInt(strRequired);//Valor de la pagina que se buscara
                  subKey = Integer.toString(x); 
                  cache.put(subKey,required);//Crea HashMap que se usara
                  
                  if(cache.get(subKey) == required)//Usando la llave se determina si el valor existe o no
                  {
                     found = true;
                  }               
                                    
                  if(found == true)//Condicion para indicar si es un Hit/Miss
                  {
                     strFound = "Hit";
                  }
                  else
                  {
                     strFound = "Miss";
                  }
                  System.out.println("Resultado: " + strFound);//Detecta si es un Hit o un Miss
                  System.out.println("Tiempo transcurrido: " + System.nanoTime());
               
                  if(found == true)//Condicion para determinar el status del sistema
                  {
                     strStatus = "No sustitucion";
                  }
                  else
                  {
                     strPagina = subKey;
                     strStatus = "Escribir en pagina " + strPagina;
                  }
                  
                  System.out.println("Status del sistema: " + strStatus);//Avisa que se hara en el cache+
               
               }
               break;       
            case 0://Exist program
               System.out.println("Adios amigos!\n");
         }
      }
   }
}